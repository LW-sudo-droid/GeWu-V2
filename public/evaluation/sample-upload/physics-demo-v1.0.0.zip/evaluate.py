import argparse
import json
import math
from pathlib import Path

def is_correct(prediction, expected):
    if not isinstance(prediction, dict):
        return False
    value = prediction.get('answer')
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return (math.isfinite(value)
            and abs(value - expected['answer']) <= 1e-6
            and prediction.get('unit') == expected['unit'])

parser = argparse.ArgumentParser(description='Score the three demonstration physics tasks.')
parser.add_argument('--data', required=True)
parser.add_argument('--predictions', required=True)
arguments = parser.parse_args()
dataset = json.loads(Path(arguments.data).read_text(encoding='utf-8'))
predictions = json.loads(Path(arguments.predictions).read_text(encoding='utf-8'))
samples = dataset['samples']
if not samples or not isinstance(predictions, dict):
    parser.error('Expected a non-empty sample list and an object keyed by task ID.')
correct = sum(is_correct(predictions.get(sample['id']), sample['expected_output']) for sample in samples)
print(json.dumps({'correct': correct, 'total': len(samples), 'accuracy_percent': correct / len(samples) * 100}))
